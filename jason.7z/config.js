module.exports = {
	JWT_SECRET: 'CSEgMm0NUk8ioNUZ3Yud',
};
